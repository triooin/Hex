package com.hyz.hex.vault.slots;

public class SlotListException extends Exception {
    public SlotListException(Throwable cause) {
        super(cause);
    }

    public SlotListException(String message) {
        super(message);
    }
}
