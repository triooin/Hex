package com.hyz.hex.vault;

public class VaultBackupPermissionException extends Exception {
    public VaultBackupPermissionException(String message) {
        super(message);
    }
}
