package com.hyz.hex.icons;

public class IconPackException extends Exception {
    public IconPackException(Throwable cause) {
        super(cause);
    }

    public IconPackException(String message) {
        super(message);
    }
}
