package com.hyz.hex;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class HexApplication extends HexApplicationBase {

}
