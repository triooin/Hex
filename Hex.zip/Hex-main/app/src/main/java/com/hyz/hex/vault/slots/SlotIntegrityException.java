package com.hyz.hex.vault.slots;

public class SlotIntegrityException extends Exception {
    public SlotIntegrityException() {

    }

    public SlotIntegrityException(Throwable cause) {
        super(cause);
    }
}
