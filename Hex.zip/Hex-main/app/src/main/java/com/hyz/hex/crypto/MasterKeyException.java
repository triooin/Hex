package com.hyz.hex.crypto;

public class MasterKeyException extends Exception {
    public MasterKeyException(Throwable cause) {
        super(cause);
    }
}
