package com.hyz.hex.ui.fragments.preferences;

import android.os.Bundle;

import com.hyz.hex.R;

public class MainPreferencesFragment extends PreferencesFragment {
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        addPreferencesFromResource(R.xml.preferences);
    }
}
