package com.hyz.hex.vault;

public class VaultEntryIconException extends Exception {
    public VaultEntryIconException(Throwable cause) {
        super(cause);
    }

    public VaultEntryIconException(String message) {
        super(message);
    }
}
