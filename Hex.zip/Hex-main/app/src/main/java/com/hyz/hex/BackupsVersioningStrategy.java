package com.hyz.hex;

public enum BackupsVersioningStrategy {
    UNDEFINED,
    MULTIPLE_BACKUPS,
    SINGLE_BACKUP
}