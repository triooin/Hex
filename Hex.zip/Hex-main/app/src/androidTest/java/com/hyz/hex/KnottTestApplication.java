package com.hyz.hex;

import dagger.hilt.android.testing.CustomTestApplication;

@CustomTestApplication(HexApplicationBase.class)
public interface HexTestApplication {
}
