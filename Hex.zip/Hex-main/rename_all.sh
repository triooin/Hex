#!/usr/bin/env bash
set -e

ORIG_ZIP="Hex-master.zip"
OLD_ROOT="Hex-master"
NEW_ROOT="Hex"

rm -rf "$OLD_ROOT" "$NEW_ROOT"
unzip -q "$ORIG_ZIP"
cd "$OLD_ROOT"

# TEXT REPLACEMENTS (SAFE TYPES)
find . \
  -type f \
  ! -path "./.git/*" \
  ! -path "./.gradle/*" \
  ! -path "*/build/*" \
  \( -name "*.java" -o -name "*.kt" -o -name "*.xml" -o -name "*.gradle" -o -name "*.properties" -o -name "*.md" -o -name "*.txt" -o -name "*.yml" -o -name "*.yaml" \) \
  -exec sed -i \
    -e 's/com\.hyz\.hex/com.hyz.hex/g' \
    -e 's/Hyzieo/Hyzieo/g' \
    -e 's/hyz/hyz/g' \
    -e 's/Hex/Hex/g' \
    -e 's/hex/hex/g' \
  {} +

# RENAME FILES & DIRS
find . -depth \
  ! -path "./.git*" \
  ! -path "./.gradle*" \
  ! -path "*build*" | while read -r p; do
    n="$p"
    n="${n//hyz/hyz}"
    n="${n//Hex/Hex}"
    n="${n//hex/hex}"
    [ "$p" != "$n" ] && mkdir -p "$(dirname "$n")" && mv "$p" "$n" 2>/dev/null || true
done

# FIX ANDROID PACKAGES
for base in app/src/{main,test,androidTest}/java; do
  [ -d "$base/com/hyz" ] && mkdir -p "$base/com/hyz" && mv "$base/com/hyz" "$base/com/hyz"
  [ -d "$base/com/hyz/hex" ] && mv "$base/com/hyz/hex" "$base/com/hyz/hex"
done

cd ..
mv "$OLD_ROOT" "$NEW_ROOT"
cd "$NEW_ROOT"

grep -R \
  --exclude-dir=.git \
  --exclude-dir=.gradle \
  --exclude-dir=build \
  "hyz\|Hyzieo\|Hex\|hex" . && exit 1 || echo "SUCCESS: NO LEFTOVERS"
